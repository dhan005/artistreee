import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Scanner;


public class Artists {

    private String artistName;
    private String fullName;
    private int yearActive;
    private static int artistID = 1000;
    //music genre
    private ArrayList<String> genre;


    void newArtists() {
        System.out.println("Enter your Alias name");
        Scanner n = new Scanner(System.in);
        this.artistName = n.nextLine();
        //provide fullname
        System.out.println("Enter your fullName");
        this.fullName = n.nextLine();
        //provide yearactive
        System.out.println("How long have you been active?");
        this.yearActive = n.nextInt();

        System.out.println(" Welcome to Artistree " + artistName);

    }
    //generate userID
    private void setID() {
        artistID++;
        System.out.println(" your userID has been generated " + artistName.charAt(0) + artistID);
    }

    //provide statuses
    public void showStatus() {
        System.out.println("\n" + artistID);
        System.out.println("\n" + "your Alias " + artistName);
        System.out.println("\n Years Active" + yearActive);
    }
    //provide newGenres
    public boolean addGenres(boolean genre) {
          boolean notSelected = true;
          if(genre = notSelected) {
              System.out.println("Enter your genre");
              Scanner select = new Scanner(System.in);
              select.nextLine();
              return false;
          } else {
              return false;
          }
    }


}
